package com.example.kcet;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PassStsFragment extends Fragment {

    ArrayList<PassStsList> list = new ArrayList<>();
    public String mUser,yr,dept,sts,path;
    public TextView no_data;
    View view;

    public int i=0,j;
    public boolean fl=false,user;
    public ProgressDialog progressDialog;
    public PassStsFragment(String path,String yr, String dept, String sts, boolean user){
        this.path=path;this.yr=yr;this.dept=dept;this.sts=sts;this.user=user;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_leave_pending, container, false);
        no_data=view.findViewById(R.id.no_data);

        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        if(user)
        {
            SharedPreferences prefs = getContext().getSharedPreferences("status", Context.MODE_PRIVATE);

            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Pass/"+path+"/"+prefs.getString("roll_no",""));
                ValueEventListener eventListener = new ValueEventListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for(DataSnapshot ds:dataSnapshot.getChildren())
                            {
                                if(ds.child("status").getValue().toString().equals(sts))
                                {
                                    list.add(new PassStsList(ds.child("name").getValue().toString(), ds.child("status").getValue().toString(), yr,dataSnapshot.getKey(),ds.getKey(),dept,ds.child("date").getValue().toString(),ds.child("leaveId").getValue().toString(),path));
                                    update();
                                }
                            }
                            if(list.isEmpty())
                            {
                                no_data.setText("No records found.");
                                no_data.setVisibility(View.VISIBLE);
                            }
                        }
                        else
                        {
                            no_data.setText("No records found.");
                            no_data.setVisibility(View.VISIBLE);
                        }
                        progressDialog.dismiss();
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity(),"Something went wrong.",Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();}
                };
                rootRef.addListenerForSingleValueEvent(eventListener);
        }
        else
        {
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Pass/"+path);
            ValueEventListener eventListener = new ValueEventListener()
            {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for(DataSnapshot ds :dataSnapshot.getChildren())
                        {
                            getData(ds.getKey());
                        }
                        progressDialog.dismiss();
                    }
                    else {
                        progressDialog.dismiss();
                        no_data.setText("No records found.");
                        no_data.setVisibility(View.VISIBLE);
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {}
            };
            rootRef.addListenerForSingleValueEvent(eventListener);
        }

        return view;
    }


    private void getData(String roll)
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Pass/"+path+"/");
        DatabaseReference scoreRef = rootRef.child(roll);

        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot ds:dataSnapshot.getChildren())
                    {
                        if(ds.child("status").getValue().toString().equals(sts))
                        {
                            list.add(new PassStsList(ds.child("name").getValue().toString(), ds.child("status").getValue().toString(), yr,dataSnapshot.getKey(),ds.getKey(),dept,ds.child("date").getValue().toString(),ds.child("leaveId").getValue().toString(),path));
                            update();
                        }
                    }
                    return;
                }
                else
                {
                    no_data.setText("No records found.");
                    no_data.setVisibility(View.VISIBLE);
                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

                progressDialog.dismiss();}
        };
        scoreRef.addListenerForSingleValueEvent(eventListener);
    }

    private void update()
    {
        if (list.isEmpty())
        {
            no_data.setText("No records found.");
            no_data.setVisibility(View.VISIBLE);
        }
        else
            no_data.setVisibility(View.GONE);

        if (getActivity()!=null) {
            PassStsListAdapter adaptor = new PassStsListAdapter(getActivity(), list);
            ListView listView = (ListView) view.findViewById(R.id.list);

            listView.setAdapter(adaptor);
        }
        progressDialog.dismiss();
    }

}