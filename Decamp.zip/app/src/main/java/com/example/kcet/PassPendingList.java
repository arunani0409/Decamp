package com.example.kcet;

class PassPendingList
{
    public String name;
    public String sts;
    public String roll;
    public String id;
    public String dept;
    public String yr;
    public String path;
    public String leaveId;

    public PassPendingList(String name, String sts, String roll, String id,String dept,String yr,String path,String leaveId)
    {
        this.name=name;
        this.sts=sts;
        this.roll=roll;
        this.id=id;
        this.yr=yr;
        this.dept=dept;
        this.path=path;
        this.leaveId=leaveId;
    }

    public String getName(){return name;}
    public String getSts(){return sts;}
    public String getId(){return id;}
    public String getRoll(){return roll;}
    public String getDept(){return dept;}
    public String getYr(){return yr;}
    public String getPath(){return path;}
    public String getLeaveId(){return leaveId;}
}
