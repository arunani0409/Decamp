package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;

public class LeaveStatusActivity extends AppCompatActivity {

    private String[] mArr=new String[4],cArr=new String[4],hArr=new String[4];
    private TextView name,roll,reason,start,end,days,year,type,time,r1,r2,r3;
    public ProgressDialog progressDialog;
    private Intent i;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_status);

        i=getIntent();
        name=findViewById(R.id.name);
        roll=findViewById(R.id.roll);
        start=findViewById(R.id.start);
        end=findViewById(R.id.end);
        time=findViewById(R.id.time);
        year=findViewById(R.id.year);
        type=findViewById(R.id.type);
        reason=findViewById(R.id.reason);
        days=findViewById(R.id.days);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Mentor's Remarks",mArr);
            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Chairperson's Remarks",cArr);
            }
        });

        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("HoD's Remarks",hArr);
            }
        });
        load();
        if(i.getStringExtra("sts").equals("Leave Approved"))
        {
                GifImageView gifImageView = (GifImageView) findViewById(R.id.gif);
            gifImageView.setImageResource(R.drawable.approval_gif);
        }
        else if(i.getStringExtra("sts").equals("Leave Rejected"))
        {
            GifImageView gifImageView = (GifImageView) findViewById(R.id.gif);
            gifImageView.setImageResource(R.drawable.reject_gif);
        }
    }

    @Override
    protected void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }


    private void load()
    {
        progressDialog= ProgressDialog.show(LeaveStatusActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef1 = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef1 = rootRef1.child("Leave").child(i.getStringExtra("dept")).child(i.getStringExtra("yr")).child(i.getStringExtra("roll")).child(i.getStringExtra("id"));
        ValueEventListener eventListener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name.setText(dataSnapshot.child("name").getValue().toString());
                    roll.setText(i.getStringExtra("roll"));
                    time.setText(dataSnapshot.child("time").getValue().toString());
                    start.setText(dataSnapshot.child("startD").getValue().toString()+" ("+dataSnapshot.child("startS").getValue().toString()+")");
                    end.setText(dataSnapshot.child("endD").getValue().toString()+" ("+dataSnapshot.child("endS").getValue().toString()+")");
                    reason.setText(dataSnapshot.child("reason").getValue().toString());
                    days.setText(dataSnapshot.child("days").getValue().toString());
                    type.setText(dataSnapshot.child("type").getValue().toString());
                    year.setText(i.getStringExtra("yr")+" / "+prefs.getString("dept",""));
                    switch (dataSnapshot.child("level").getValue().toString())
                    {
                        case "0":
                            r1.setVisibility(View.GONE);
                            r2.setVisibility(View.GONE);
                            r3.setVisibility(View.GONE);
                            break;
                        case "1":
                            r2.setVisibility(View.GONE);
                            r3.setVisibility(View.GONE);

                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();
                            break;
                        case "2":
                            r3.setVisibility(View.GONE);

                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                            cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                            cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();
                            break;
                        case "3":
                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                            cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                            cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();

                            hArr[0]=dataSnapshot.child("hod/name").getValue().toString();hArr[1]=dataSnapshot.child("hod/remark").getValue().toString();
                            hArr[2]=dataSnapshot.child("hod/time").getValue().toString();hArr[3]=dataSnapshot.child("hod/status").getValue().toString();
                            break;
                    }
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found. Contact Admin!", Snackbar.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef1.addListenerForSingleValueEvent(eventListener1);
    }

    private void remarkPop(String title, String[] arr) {
        View alertCustomdialog = LayoutInflater.from(LeaveStatusActivity.this).inflate(R.layout.remarks_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(LeaveStatusActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView name = alertCustomdialog.findViewById(R.id.name);
        TextView remark = alertCustomdialog.findViewById(R.id.remark);
        TextView time = alertCustomdialog.findViewById(R.id.time);
        TextView status = alertCustomdialog.findViewById(R.id.status);
        //setting data
        if(arr[3].equals("Approved"))
            status.setTextColor(getResources().getColor(R.color.green));
        else
            status.setTextColor(getResources().getColor(R.color.red));
        t.setText(title);
        name.setText(arr[0]);
        remark.setText(arr[1]);
        status.setText(arr[3]);
        time.setText(arr[2]);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss(); }
        });
    }
}