package com.example.kcet;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class LeavePendingFragment extends Fragment {

    ArrayList<LeavePendingList> list = new ArrayList<>();
    public String mUser,yr,dept;
    public TextView no_data;
    View view;
    public ProgressDialog progressDialog;
    public LeavePendingFragment(String mUser,String yr,String dept){
        this.mUser=mUser;this.yr=yr;this.dept=dept;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_leave_pending, container, false);
        no_data=view.findViewById(R.id.no_data);
        //now you must initialize your list view
        //EDITED Code
        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("LeavePending/"+dept+"/"+yr);
        Query scoreRef = rootRef.child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            getData(ds.getKey(),ds.getValue().toString());
                    }
                }
                else {
                    no_data.setText("There is no pending leave requests in "+yr);
                    no_data.setVisibility(View.VISIBLE);
                    progressDialog.dismiss();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        scoreRef.addListenerForSingleValueEvent(eventListener);

        return view;
    }

    private void getData(String id,String roll)
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Leave/"+dept+"/"+yr);
        Query scoreRef = rootRef.child(roll).child(id);

        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot ds) {
                if (ds.exists()) {
                    list.add(new LeavePendingList(ds.child("name").getValue().toString(), ds.child("status").getValue().toString(), yr,roll, id));
                    if (list.isEmpty())
                    {
                        no_data.setText("There is no pending leave requests in "+yr);
                        no_data.setVisibility(View.VISIBLE);
                    }
                    else
                        no_data.setVisibility(View.GONE);

                    if (getActivity()!=null) {
                        LeavePendingListAdapter adaptor = new LeavePendingListAdapter(getActivity(), list);
                        ListView listView = (ListView) view.findViewById(R.id.list);

                        listView.setAdapter(adaptor);
                        progressDialog.dismiss();
                    }
                    progressDialog.dismiss();
                    return;
                }
                else {
                    no_data.setText("There is no pending leave requests in "+yr);
                    no_data.setVisibility(View.VISIBLE);
                    progressDialog.dismiss();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        scoreRef.addListenerForSingleValueEvent(eventListener);
    }
}