package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LeaveActivity extends AppCompatActivity {
    private int index=0,yr=1;
    public ProgressDialog progressDialog;
    public String mUser="";
    private SharedPreferences prefs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave);
        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");
        load();

        TabLayout tabLayout=findViewById(R.id.tabMode);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                index=tab.getPosition();
                load();
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) { }
            @Override
            public void onTabReselected(TabLayout.Tab tab) { }
        });

    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id._1:
                yr=1;
                load();
                break;
            case R.id._2:
                yr=2;
                load();
                break;
            case R.id._3:
                yr=3;
                load();
                break;
            case R.id._4:
                yr=4;
                load();
                break;
        }
    }

    private void load()
    {
        if(index==0)
        {
            LeavePendingFragment fragment=new LeavePendingFragment(mUser,yr+"yr",prefs.getString("dept",""));
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
        else if(index==1)
        {
            LeaveStsFragment fragment=new LeaveStsFragment(mUser,yr+"yr",prefs.getString("dept",""),"Leave Approved",false);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
        else if(index==2)
        {
            LeaveStsFragment fragment=new LeaveStsFragment(mUser,yr+"yr",prefs.getString("dept",""),"Leave Rejected",false);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
    }



    @Override
    protected void onResume() {
        load();
        super.onResume();
    }
}