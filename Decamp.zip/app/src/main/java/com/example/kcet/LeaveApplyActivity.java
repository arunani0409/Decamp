package com.example.kcet;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LeaveApplyActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    private String[] country = { "-Select Leave Type-", "Leave", "On Duty"};
    private Calendar myCalendar= Calendar.getInstance();
    private EditText startDate,endDate,reason;
    private RadioButton startAn,startFn,endFn,endAn;
    private int sSession=0,eSession=0,leaveType=0,mDays=0;
    private Button button;
    private String start="",end="",mReason="",mUser="";
    public ProgressDialog progressDialog;
    public String tym;
    String myFormat="dd/MM/yy";
    private TextView days;
    private SharedPreferences prefs;
    SimpleDateFormat f_year = new SimpleDateFormat("yy");
    SimpleDateFormat f_mon = new SimpleDateFormat("MM");
    SimpleDateFormat f_day = new SimpleDateFormat("dd");
    SimpleDateFormat f_hour = new SimpleDateFormat("HH");
    SimpleDateFormat f_min = new SimpleDateFormat("mm");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_apply);

        reason=findViewById(R.id.reason);
        button=findViewById(R.id.submit);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        time();

        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);

        startAn=findViewById(R.id.startAn);
        endAn=findViewById(R.id.endAn);
        startFn=findViewById(R.id.startFn);
        endFn=findViewById(R.id.endFn);
        days=findViewById(R.id.days);

        Button sub=findViewById(R.id.sub);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mDays!=0)
                    mDays--;
                days.setText(""+mDays);
            }
        });

        Button add=findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDays++;
                days.setText(""+mDays);
            }
        });

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, country);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);

        button=findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mReason=reason.getText().toString();
                end=endDate.getText().toString();
                start=startDate.getText().toString();
                if(leaveType!=0) {
                    if(!end.equals("")&&!start.equals(""))
                    {
                        if(mDays!=0)
                        {
                            if(mReason.equals(""))
                                Snackbar.make(findViewById(R.id.parent),"Please type the reason!",Snackbar.LENGTH_SHORT).show();
                            else
                            {
                                mentor();
                            }
                        }
                        else
                            Snackbar.make(findViewById(R.id.parent),"Please select the no of leave days",Snackbar.LENGTH_SHORT).show();
                    }
                    else
                        Snackbar.make(findViewById(R.id.parent),"Please select dates",Snackbar.LENGTH_SHORT).show();
                }
                else
                    Snackbar.make(findViewById(R.id.parent),"Please select the leave type",Snackbar.LENGTH_SHORT).show();
            }
        });

        startDate=(EditText) findViewById(R.id.startDate);
        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel(startDate);
            }
        };

        startDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(LeaveApplyActivity.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDate=(EditText) findViewById(R.id.endDate);
        DatePickerDialog.OnDateSetListener date1 =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel(endDate);
            }
        };

        endDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(LeaveApplyActivity.this,date1,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        if(country[position].equals("Leave"))
            leaveType=1;
        else if (country[position].equals("On Duty"))
            leaveType=2;
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }

    private void updateLabel(EditText editText){
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        String temp=dateFormat.format(myCalendar.getTime());
        editText.setText(temp);
        if(editText.getId()==R.id.startDate)
            start=temp;
        else if(editText.getId()==R.id.endDate)
            end=temp;
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.startFn:
                if (checked)
                    startAn.setChecked(false);
                    sSession=1;
                    break;
            case R.id.startAn:
                if (checked)
                    startFn.setChecked(false);
                    sSession=2;
                    break;
            case R.id.endFn:
                if (checked)
                    endAn.setChecked(false);
                    eSession=1;
                    break;
            case R.id.endAn:
                if (checked)
                    endFn.setChecked(false);
                    eSession=2;
                    break;
        }
    }

    private void mentor()
    {

        progressDialog = ProgressDialog.show(LeaveApplyActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        mUser = prefs.getString("roll_no", "");

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        writeData(dataSnapshot.child("mentor").getValue().toString(),dataSnapshot.child("name").getValue().toString());
                    }
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void writeData(String mentor,String name)
    {
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Leave").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(prefs.getString("roll_no",""));
        DatabaseReference user=ref.push();
        String id=user.getKey();

        user.child("time").setValue(tym);
        user.child("reason").setValue(mReason);
        user.child("startD").setValue(start);
        user.child("endD").setValue(end);
        user.child("days").setValue(mDays);
        user.child("level").setValue(0);
        user.child("name").setValue(name);
        if(sSession==1)
            user.child("startS").setValue("Full Day");
        else
            user.child("startS").setValue("Half Day");
        if(eSession==1)
            user.child("endS").setValue("Full Day");
        else
            user.child("endS").setValue("Half Day");
        user.child("status").setValue("Pending");
        if(leaveType==1)
            user.child("type").setValue("Leave");
        else
            user.child("type").setValue("On Duty");

        DatabaseReference ref1= FirebaseDatabase.getInstance().getReference("LeavePending").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(mentor);
        ref1.child(id).setValue(mUser);

        progressDialog.dismiss();
        Toast.makeText(LeaveApplyActivity.this, "Leave Submitted Successfully!", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    public void time() {
        DatabaseReference offsetRef = FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset");
        offsetRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long offset = snapshot.getValue(long.class);
                long estimatedServerTimeMs = System.currentTimeMillis() + offset;
                String year = f_year.format(new Date(estimatedServerTimeMs));
                String mon = f_mon.format(new Date(estimatedServerTimeMs));
                String day = f_day.format(new Date(estimatedServerTimeMs));
                tym=day+"-"+mon+"-"+year+" "+f_hour.format(new Date(estimatedServerTimeMs))+":"+f_min.format(new Date(estimatedServerTimeMs));
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }
}