package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.internal.NavigationMenuView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class StaffActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private NavigationView navigationView;
    public DrawerLayout drawerLayout;
    private SharedPreferences prefs;
    private String mUser;
    private TextView name;
    private ImageView imageView;
    public Intent intent;
    private LinearLayout l2;
    public boolean pass=true;
    public ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        navigationView = findViewById(R.id.navigation_view);
        NavigationMenuView navigationMenu = (NavigationMenuView) navigationView.getChildAt(0);
        navigationMenu.setVerticalScrollBarEnabled(false);
        drawerLayout = findViewById(R.id.drawer);

        name=findViewById(R.id.name);
        imageView=findViewById(R.id.person);

        ImageView opener = findViewById(R.id.person);
        opener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();

        l2=findViewById(R.id.l2);
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StaffActivity.this,PassActivity.class));
            }
        });

        load();

        LinearLayout l1=findViewById(R.id.l1);
        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StaffActivity.this,LeaveActivity.class));
            }
        });


    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent i = null;
        switch (item.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_profile:
                i = new Intent(StaffActivity.this, ProfileStaffActivity.class);
                break;
            case R.id.nav_canteen:
                i = new Intent(StaffActivity.this, CanteenActivity.class);
                break;
            case R.id.nav_search:
                i = new Intent(StaffActivity.this, SearchActivity.class);
                break;
            case R.id.nav_leave:
                i = new Intent(StaffActivity.this, LeaveActivity.class);
                break;
            case R.id.nav_out:
                popUp("Warning!","Are you sure want to logout?","STAY","LOGOUT",new Intent(StaffActivity.this,LoginActivity2.class));
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        if (i != null)
            startActivity(i);
        return false;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isOpen())
            drawerLayout.closeDrawer(GravityCompat.START);
        else
            finishAffinity();
    }

    private void popUp(String title, String msg, String b1, String b2, Intent i) {
        View alertCustomdialog = LayoutInflater.from(StaffActivity.this).inflate(R.layout.popup_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(StaffActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button cancel = alertCustomdialog.findViewById(R.id.cancel);
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView m = alertCustomdialog.findViewById(R.id.msg);
        //setting data
        cancel.setText(b1);
        ok.setText(b2);
        t.setText(title);
        m.setText(msg);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.clear();
                editor.commit();
                dialog.dismiss();
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });
    }

    private void load()
    {
        progressDialog = ProgressDialog.show(StaffActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");

        name.setText(mUser);

        if(!prefs.getString("role","").equals("Prof"))
        {
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Reference/staff/"+mUser+"/role2");
            ValueEventListener eventListener = new ValueEventListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("hostel", dataSnapshot.child("hostel").getValue().toString());
                        editor.putString("hyr", dataSnapshot.child("yr").getValue().toString());
                        editor.apply();

                    }
                    else
                    {
                        l2.setVisibility(View.GONE);
                        pass=false;
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {}
            };
            rootRef.addListenerForSingleValueEvent(eventListener);
        }
        else
        {
            l2.setVisibility(View.VISIBLE);
            pass=false;
        }

        final long ONE_MEGABYTE = 1024 * 1024;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("/"+mUser+".jpg");

        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                imageView.setImageBitmap(bmp);
                setDrawerData(bmp);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });
    }

    public void setDrawerData(Bitmap bmp)
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StaffData").child(prefs.getString("dept","")).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    View header = navigationView.getHeaderView(0);
                    TextView nav_name = header.findViewById(R.id.nav_name);
                    TextView nav_mob = header.findViewById(R.id.nav_mob);
                    ImageView nav_photo=header.findViewById(R.id.nav_person);

                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("name", dataSnapshot.child("name").getValue().toString());
                    editor.apply();

                    nav_mob.setText(prefs.getString("role","")+" / "+prefs.getString("dept",""));
                    nav_name.setText(dataSnapshot.child("name").getValue().toString());
                    nav_photo.setImageBitmap(bmp);
                }
                else
                    Snackbar.make(findViewById(R.id.drawer), "data not found!", Snackbar.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.drawer), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }
}