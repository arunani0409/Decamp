package com.example.kcet;

import static android.graphics.Color.WHITE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;

public class SplashActivity extends AppCompatActivity {

    public Intent intent;
    private static int SPLASH_SCREEN_TIME_OUT=2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(WHITE);
        }
        setContentView(R.layout.activity_splash);

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        if (prefs.getString("roll_no", "").equals(""))
        {
                intent  = new Intent(this, LoginActivity.class);
        }
        else
        {
            if(!prefs.getString("role", "").equals(""))
                intent=new Intent(this,StaffActivity.class);
            else
                intent=new Intent(this,StdActivity.class);
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
                finish();
            }
        }, SPLASH_SCREEN_TIME_OUT);
    }
}