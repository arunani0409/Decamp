package com.example.kcet;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GateActivity extends AppCompatActivity {

    TextView status,logout,reset;
    public ProgressDialog progressDialog;
    SimpleDateFormat f_year = new SimpleDateFormat("yy");
    SimpleDateFormat f_mon = new SimpleDateFormat("MM");
    SimpleDateFormat f_day = new SimpleDateFormat("dd");
    SimpleDateFormat f_hour = new SimpleDateFormat("HH");
    SimpleDateFormat f_min = new SimpleDateFormat("mm");
    public String tym="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gate);

        reset=findViewById(R.id.reset);
        logout=findViewById(R.id.logout);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status.setVisibility(View.INVISIBLE);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp("Warning!","Are you sure want to logout?","STAY","LOGOUT",new Intent(GateActivity.this,LoginActivity2.class));
            }
        });

        status=findViewById(R.id.status);
        status.setVisibility(View.INVISIBLE);

        Button scan=findViewById(R.id.scan);
        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(GateActivity.this, PassReadActivity.class);
                startActivityForResult(i, 1);
            }
        });


    }

    private void update(String path)
    {
        progressDialog= ProgressDialog.show(GateActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference(path);
        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot ds) {
                if (ds.exists()) {
                    if(ds.getValue().toString().equals("null"))
                    {
                        status.setText("Allowed");
                        status.setTextColor(getResources().getColor(R.color.green));
                        status.setVisibility(View.VISIBLE);
                        //updating time
                        rootRef.setValue(tym);
                    }
                    else
                    {
                        status.setText("Denied");
                        status.setTextColor(getResources().getColor(R.color.red));
                        status.setVisibility(View.VISIBLE);
                    }
                }
                else {
                    status.setText("Denied");
                    status.setTextColor(getResources().getColor(R.color.red));
                    status.setVisibility(View.VISIBLE);
                }
                progressDialog.dismiss();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(GateActivity.this,"Something went wrong. Contact Admin!",Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();}
        };
        rootRef.addListenerForSingleValueEvent(eventListener);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                time();
                update(data.getStringExtra("path"));
            }
        }
    }

    private void popUp(String title, String msg, String b1, String b2, Intent i) {
        View alertCustomdialog = LayoutInflater.from(GateActivity.this).inflate(R.layout.popup_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(GateActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button cancel = alertCustomdialog.findViewById(R.id.cancel);
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView m = alertCustomdialog.findViewById(R.id.msg);
        //setting data
        cancel.setText(b1);
        ok.setText(b2);
        t.setText(title);
        m.setText(msg);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });
    }

    public void time() {
        DatabaseReference offsetRef = FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset");
        offsetRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long offset = snapshot.getValue(long.class);
                long estimatedServerTimeMs = System.currentTimeMillis() + offset;
                String year = f_year.format(new Date(estimatedServerTimeMs));
                String mon = f_mon.format(new Date(estimatedServerTimeMs));
                String day = f_day.format(new Date(estimatedServerTimeMs));
                tym=day+"-"+mon+"-"+year+" "+f_hour.format(new Date(estimatedServerTimeMs))+":"+f_min.format(new Date(estimatedServerTimeMs));
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }
}