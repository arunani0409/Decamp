package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class SearchActivity extends AppCompatActivity {

    private TextView name,yr,dept,mail;
    public String num1,num2,roll="";
    public ProgressDialog progressDialog;
    public Button callParent,callStd,mSearch;
    private ImageView image;
    public LinearLayout l1,l2;
    public CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        EditText ip=findViewById(R.id.roll);

        name=findViewById(R.id.name);
        yr=findViewById(R.id.yr);
        dept=findViewById(R.id.dept);
        mail=findViewById(R.id.mail);

        callParent=findViewById(R.id.callParent);
        callStd=findViewById(R.id.callStd);
        mSearch=findViewById(R.id.search);

        image=findViewById(R.id.image);

        l1=findViewById(R.id.layout);
        l2=findViewById(R.id.l1);
        cardView=findViewById(R.id.myCardView);

        mSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                roll=ip.getText().toString();
                if(!roll.equals(""))
                    search();
                else
                    Snackbar.make(findViewById(R.id.parent), "Enter student's Roll No to search!", Snackbar.LENGTH_SHORT).show();
            }
        });

        callParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", num1, null));
                startActivity(intent);
            }
        });
        callStd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", num2, null));
                startActivity(intent);
            }
        });

    }

    private void search()
    {
        progressDialog = ProgressDialog.show(SearchActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("Reference/std").child(roll);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()) {
                    Snackbar.make(findViewById(R.id.parent),"Roll No not found. Please correct details!",Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
                else {
                    cardView.setVisibility(View.VISIBLE);
                    l1.setVisibility(View.VISIBLE);
                    l2.setVisibility(View.VISIBLE);
                    load(dataSnapshot.child("dept").getValue().toString(),dataSnapshot.child("year").getValue().toString());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }

    private void load(String dep,String year)
    {
        final long ONE_MEGABYTE = 1024 * 1024;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("/"+roll+".jpg");

        image=findViewById(R.id.image);
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                image.setImageBitmap(bmp);
                progressDialog.dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(dep).child(year).child(roll);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    name.setText(dataSnapshot.child("name").getValue().toString());
                    mail.setText(dataSnapshot.child("mail").getValue().toString());
                    dept.setText(dep);
                    yr.setText(year);

                    num1=dataSnapshot.child("parent_no").getValue().toString();
                    num2=dataSnapshot.child("phno").getValue().toString();
                }
                else
                    Snackbar.make(findViewById(R.id.parent), "Data not found!", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }
}