package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.tabs.TabLayout;

import java.text.SimpleDateFormat;

public class PassActivity extends AppCompatActivity {

    private int index=0,yr=1;
    public ProgressDialog progressDialog;
    public String path="",dept="IT";
    public RadioGroup r1,r2;
    public boolean hosteler;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass);

        r1=findViewById(R.id.radio1);
        r2=findViewById(R.id.radio2);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        if(prefs.getString("role","").equals("Prof"))
        {
            path="DS/"+prefs.getString("dept","")+"/";
            hosteler=false;
            dept=prefs.getString("dept","");
            r2.setVisibility(View.INVISIBLE);
        }
        else
        {
            path="HS/"+prefs.getString("hostel","")+"/"+prefs.getString("hyr","")+"yr/";
            hosteler=true;
            r1.setVisibility(View.INVISIBLE);
            yr=Integer.parseInt(prefs.getString("hyr",""));
        }

        load();

        TabLayout tabLayout=findViewById(R.id.tabMode);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                index=tab.getPosition();
                load();
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) { }
            @Override
            public void onTabReselected(TabLayout.Tab tab) { }
        });
    }

    public void onRadioButtonClicked(View view) {
        switch(view.getId()) {
            case R.id._1:
                yr=1;
                load();
                break;
            case R.id._2:
                yr=2;
                load();
                break;
            case R.id._3:
                yr=3;
                load();
                break;
            case R.id._4:
                yr=4;
                load();
                break;
        }
    }

    public void onDeptClicked(View view) {
        switch(view.getId()) {
            case R.id.d1:
                dept="IT";
                load();
                break;
            case R.id.d2:
                dept="CSE";
                load();
                break;
            case R.id.d3:
                dept="ECE";
                load();
                break;
            case R.id.d4:
                dept="BT";
                load();
                break;
            case R.id.d5:
                dept="MECH";
                load();
                break;
        }
    }

    private void load()
    {
        String temp;
        if(hosteler)
            temp=path+dept;
        else
            temp=path+yr+"yr/";

        if(index==0)
        {
            PassPendingFragment fragment=new PassPendingFragment(temp,hosteler,dept,yr+"yr");
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
        else if(index==1)
        {
            PassStsFragment fragment=new PassStsFragment(temp,yr+"yr",dept,"Pass Approved",false);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
        else if(index==2)
        {
            PassStsFragment fragment=new PassStsFragment(temp,yr+"yr",dept,"Pass Rejected",false);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
    }

    @Override
    protected void onResume() {
        load();
        super.onResume();
    }
}