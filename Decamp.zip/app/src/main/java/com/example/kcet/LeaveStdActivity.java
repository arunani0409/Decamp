package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class LeaveStdActivity extends AppCompatActivity {

    private int index = 0;
    public ProgressDialog progressDialog;
    public String mUser = "";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_std);
        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");
        load();

        TabLayout tabLayout = findViewById(R.id.tabMode);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                index = tab.getPosition();
                load();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    private void load() {
        if (index == 0) {
            LeaveStdPendFragment fragment = new LeaveStdPendFragment(mUser, prefs.getString("yr", ""), prefs.getString("dept", ""));
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        } else if (index == 1) {
            LeaveStsFragment fragment = new LeaveStsFragment(mUser, prefs.getString("yr", ""), prefs.getString("dept", ""), "Leave Approved",true);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        } else if (index == 2) {
            LeaveStsFragment fragment = new LeaveStsFragment(mUser, prefs.getString("yr", ""), prefs.getString("dept", ""), "Leave Rejected",true);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            fragmentTransaction.commit();
        }
    }


}