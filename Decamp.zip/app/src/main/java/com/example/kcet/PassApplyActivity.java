package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class PassApplyActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    public String[] country,newDate,newKey;
    public String mUser,key="",mReason="",mDate="";
    private EditText startDate,reason;
    private Calendar myCalendar= Calendar.getInstance();
    public SharedPreferences prefs;
    public ProgressDialog progressDialog;
    public String tym;
    public Button button;
    String myFormat="dd/MM/yy";
    SimpleDateFormat f_year = new SimpleDateFormat("yy");
    SimpleDateFormat f_mon = new SimpleDateFormat("MM");
    SimpleDateFormat f_day = new SimpleDateFormat("dd");
    SimpleDateFormat f_hour = new SimpleDateFormat("HH");
    SimpleDateFormat f_min = new SimpleDateFormat("mm");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_apply);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        progressDialog = ProgressDialog.show(PassApplyActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        time();

        startDate=(EditText) findViewById(R.id.outDate);
        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel(startDate);
            }
        };

        startDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(PassApplyActivity.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        mUser = prefs.getString("roll_no", "");

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("Leave").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int len=(int)dataSnapshot.getChildrenCount(),i=0,count=0;
                    country=new String[len];

                    String[] key=new String[len];

                    for(DataSnapshot ds : dataSnapshot.getChildren())
                    {
                        if(ds.child("status").getValue().toString().equals("Leave Approved"))
                        {
                            country[i]=ds.child("startD").getValue().toString()+" - "+ds.child("endD").getValue().toString();
                            key[i]=ds.getKey();
                            count++;
                        }

                        else
                        {
                            country[i]=" ";
                            key[i]=" ";
                        }
                        i++;
                        if(i>=len)
                        {
                               setSpinnerData(key,count);
                        }
                    }
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);

        reason=findViewById(R.id.reason);
        button=findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mReason = reason.getText().toString();
                mDate = startDate.getText().toString();
                if(!key.equals(""))
                {
                    if(!mDate.equals(""))
                    {
                        if (!mReason.equals(""))
                        {
                            writeData();
                        }
                        else
                            Snackbar.make(findViewById(R.id.parent),"Please type the reason!",Snackbar.LENGTH_SHORT).show();
                    }
                    else
                        Snackbar.make(findViewById(R.id.parent),"Please select dates",Snackbar.LENGTH_SHORT).show();
                }
                else
                    Snackbar.make(findViewById(R.id.parent),"Please select approved leave",Snackbar.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(i!=0)
        {
            key=newKey[i-1];
        }
        else
            key="";
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }

    public void setSpinnerData(String[] key,int count)
    {
        newDate=new String[count+1];
        newKey=new String[count];
        newDate[0]="-Select leave to apply-";

        int fl=1;

        for(int i=0;i< country.length;i++)
        {
            if(!country[i].equals(" "))
            {
                newDate[fl]=country[i];
                newKey[fl-1]=key[i];
                fl++;
            }
        }

        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, newDate);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spin.setAdapter(aa);

        progressDialog.dismiss();
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if ( progressDialog!=null && progressDialog.isShowing() ){
            progressDialog.cancel();
        }
    }

    public void time() {
        DatabaseReference offsetRef = FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset");
        offsetRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long offset = snapshot.getValue(long.class);
                long estimatedServerTimeMs = System.currentTimeMillis() + offset;
                String year = f_year.format(new Date(estimatedServerTimeMs));
                String mon = f_mon.format(new Date(estimatedServerTimeMs));
                String day = f_day.format(new Date(estimatedServerTimeMs));
                tym=day+"-"+mon+"-"+year+" "+f_hour.format(new Date(estimatedServerTimeMs))+":"+f_min.format(new Date(estimatedServerTimeMs));
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }

    private void updateLabel(EditText editText){
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        String temp=dateFormat.format(myCalendar.getTime());
        editText.setText(temp);
        if(editText.getId()==R.id.startDate)
            mDate=temp;
    }

    private void writeData()
    {
        String temp;
        if(prefs.getString("stay","").equals("DS"))
            temp="DS/"+prefs.getString("dept","")+"/"+prefs.getString("yr","");
        else if(prefs.getString("gender","Male").equals("Male"))
            temp="HS/BH/"+prefs.getString("yr","")+"/"+prefs.getString("dept","");
        else
            temp="HS/GH/"+prefs.getString("yr","")+"/"+prefs.getString("dept","");

        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Pass").child(temp).child(prefs.getString("roll_no",""));
        DatabaseReference user=ref.push();
        String id=user.getKey();
        user.child("time").setValue(tym);
        user.child("reason").setValue(mReason);
        user.child("date").setValue(mDate);
        user.child("leaveId").setValue(key);
        user.child("status").setValue("Pending");
        user.child("name").setValue(prefs.getString("name",""));

        DatabaseReference ref1= FirebaseDatabase.getInstance().getReference("PassPending").child(temp);
        ref1.child(id).setValue(mUser);

        progressDialog.dismiss();
        Toast.makeText(PassApplyActivity.this, "Pass request Submitted Successfully!", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }
}