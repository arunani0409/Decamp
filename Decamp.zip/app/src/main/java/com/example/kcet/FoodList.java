package com.example.kcet;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

class FoodList
{
    public String name;
    public String price;

    public FoodList(String name, String price)
    {
        this.name=name;
        this.price=price;
    }

    public String getName(){return name;}
    public String getPrice(){return price;}
}
