package com.example.kcet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class LeavePendingList
{
    public String name;
    public String sts;
    public String yr;
    public String roll;
    public String id;

    public LeavePendingList(String name, String sts, String yr, String roll, String id)
    {
        this.name=name;
        this.sts=sts;
        this.yr=yr;
        this.roll=roll;
        this.id=id;
    }

    public String getName(){return name;}
    public String getSts(){return sts;}
    public String getYr(){return yr;}
    public String getId(){return id;}
    public String getRoll(){return roll;}
}
