package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

public class FeesActivity extends AppCompatActivity {

    private CardView c1,c2;
    private TextView[] t=new TextView[2];
    private TextView[] a=new TextView[2];
    private int[] amt=new int[2];
    private TextView no_data;
    public ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fees);

        c1=findViewById(R.id.card1);
        c2=findViewById(R.id.card2);
        t[0]=findViewById(R.id.t1);
        t[1]=findViewById(R.id.t2);
        a[0]=findViewById(R.id.amt1);
        a[1]=findViewById(R.id.amt2);
        no_data=findViewById(R.id.no_data);

        load();

        Button pay1=findViewById(R.id.pay1);
        pay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PaymentFragment temp = PaymentFragment.newInstance(amt[0]);
                temp.show(getSupportFragmentManager(),
                        "add_photo_dialog_fragment");
            }
        });

        Button pay2=findViewById(R.id.pay2);
        pay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PaymentFragment temp = PaymentFragment.newInstance(amt[1]);
                temp.show(getSupportFragmentManager(),
                        "add_photo_dialog_fragment");
            }
        });

        TabLayout tabLayout=findViewById(R.id.tabMode);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if(tab.getPosition()==0)
                {
                    c1.setVisibility(View.VISIBLE);
                    c2.setVisibility(View.VISIBLE);
                    no_data.setVisibility(View.INVISIBLE);
                    load();
                }
                else
                {
                    c1.setVisibility(View.INVISIBLE);
                    c2.setVisibility(View.INVISIBLE);
                    no_data.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) { }
            @Override
            public void onTabReselected(TabLayout.Tab tab) { }
        });
    }



    public void startPayment(int amt)
    {
        String url="upi://pay?pa=arunani0409@okaxis&pn=Arun%20Prasath&am="+amt+"&cu=INR&aid=uGICAgIDNmv2IPQ";
        Uri uri = Uri.parse(url);

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivityForResult(intent, 1421);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==1421)
        {
            if (resultCode==RESULT_OK)
            {
                assert data != null;
                Log.e("data","response "+data.getStringExtra("response"));
                Toast.makeText(this, "response : "+data.getStringExtra("response"), Toast.LENGTH_LONG).show();

            }
        }
    }

    private void load()
    {
        progressDialog = ProgressDialog.show(FeesActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("Fees").child(prefs.getString("dept","")).child(prefs.getString("roll_no","")).child("pending/4th Year");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int i=0;
                if (dataSnapshot.exists()) {
                    for(DataSnapshot ds : dataSnapshot.getChildren())
                    {
                        t[i].setText(ds.getKey());
                        a[i].setText("₹ "+ds.getValue().toString());
                        amt[i]= Integer.parseInt(ds.getValue().toString());
                        i++;
                    }
                    progressDialog.dismiss();
                }
                else
                    Snackbar.make(findViewById(R.id.parent), "Data not found!", Snackbar.LENGTH_SHORT).show();
                }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }

}