package com.example.kcet;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class LeaveStdPendFragment extends Fragment {

    ArrayList<LeaveStsList> list = new ArrayList<>();
    public String mUser,yr,dept;
    public TextView no_data;
    View view;
    private ScrollView scrollView;
    private String[] mArr=new String[4],cArr=new String[4],hArr=new String[4];
    private TextView name,roll,reason,start,end,days,year,type,time,r1,r2,r3;
    public ProgressDialog progressDialog;

    public LeaveStdPendFragment(String mUser, String yr, String dept){
        this.mUser=mUser;this.yr=yr;this.dept=dept;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_leave_std_pend, container, false);
        scrollView=view.findViewById(R.id.layout);
        no_data=view.findViewById(R.id.no_data);
        name=view.findViewById(R.id.name);
        roll=view.findViewById(R.id.roll);
        start=view.findViewById(R.id.start);
        end=view.findViewById(R.id.end);
        time=view.findViewById(R.id.time);
        year=view.findViewById(R.id.year);
        type=view.findViewById(R.id.type);
        reason=view.findViewById(R.id.reason);
        days=view.findViewById(R.id.days);
        r1=view.findViewById(R.id.r1);
        r2=view.findViewById(R.id.r2);
        r3=view.findViewById(R.id.r3);

        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Leave/"+dept+"/"+yr+"/"+mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot ds) {
                if (ds.exists()) {
                    for(DataSnapshot dataSnapshot:ds.getChildren())
                    {
                        if(!dataSnapshot.child("status").getValue().toString().equals("Leave Approved") && !dataSnapshot.child("status").getValue().toString().equals("Leave Rejected"))
                        {
                            scrollView.setVisibility(View.VISIBLE);
                            name.setText(dataSnapshot.child("name").getValue().toString());
                            roll.setText(mUser);
                            time.setText(dataSnapshot.child("time").getValue().toString());
                            start.setText(dataSnapshot.child("startD").getValue().toString()+" ("+dataSnapshot.child("startS").getValue().toString()+")");
                            end.setText(dataSnapshot.child("endD").getValue().toString()+" ("+dataSnapshot.child("endS").getValue().toString()+")");
                            reason.setText(dataSnapshot.child("reason").getValue().toString());
                            days.setText(dataSnapshot.child("days").getValue().toString());
                            type.setText(dataSnapshot.child("type").getValue().toString());
                            year.setText(yr+" / "+dept);
                            switch (dataSnapshot.child("level").getValue().toString())
                            {
                                case "0":
                                    r1.setVisibility(View.GONE);
                                    r2.setVisibility(View.GONE);
                                    r3.setVisibility(View.GONE);
                                    break;
                                case "1":
                                    r2.setVisibility(View.GONE);
                                    r3.setVisibility(View.GONE);

                                    mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                                    mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();
                                    break;
                                case "2":
                                    r3.setVisibility(View.GONE);

                                    mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                                    mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                                    cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                                    cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();
                                    break;
                                case "3":
                                    mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                                    mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                                    cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                                    cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();

                                    hArr[0]=dataSnapshot.child("hod/name").getValue().toString();hArr[1]=dataSnapshot.child("hod/remark").getValue().toString();
                                    hArr[2]=dataSnapshot.child("hod/time").getValue().toString();hArr[3]=dataSnapshot.child("hod/status").getValue().toString();
                                    break;
                            }
                            no_data.setVisibility(View.INVISIBLE);
                        }
                        progressDialog.dismiss();
                    }
                }
                else {
                    progressDialog.dismiss();
                    no_data.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {Toast.makeText(getActivity(),"Something went wrong. Contact Admin!",Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();}
        };
        rootRef.addListenerForSingleValueEvent(eventListener);


        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Mentor's Remarks",mArr);
            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Chairperson's Remarks",cArr);
            }
        });

        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("HoD's Remarks",hArr);
            }
        });

        return view;
    }

    private void remarkPop(String title, String[] arr) {
        View alertCustomdialog = LayoutInflater.from(getActivity()).inflate(R.layout.remarks_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
        alert.setView(alertCustomdialog);
        //init views
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView name = alertCustomdialog.findViewById(R.id.name);
        TextView remark = alertCustomdialog.findViewById(R.id.remark);
        TextView time = alertCustomdialog.findViewById(R.id.time);
        TextView status = alertCustomdialog.findViewById(R.id.status);
        //setting data
        if(arr[3].equals("Approved"))
            status.setTextColor(getResources().getColor(R.color.green));
        else
            status.setTextColor(getResources().getColor(R.color.red));
        t.setText(title);
        name.setText(arr[0]);
        remark.setText(arr[1]);
        status.setText(arr[3]);
        time.setText(arr[2]);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss(); }
        });
    }

    @Override
    public void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }
}