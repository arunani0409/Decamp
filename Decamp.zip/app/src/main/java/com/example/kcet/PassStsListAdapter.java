package com.example.kcet;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

// FirebaseRecyclerAdapter is a class provided by
// FirebaseUI. it provides functions to bind, adapt and show
// database contents in a Recycler View

public class PassStsListAdapter extends ArrayAdapter<PassStsList> {

    public PassStsListAdapter(Activity context, ArrayList<PassStsList> words) {
        super(context, 0, words);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.leave_list_std, parent, false);
        }

        PassStsList obj = getItem(position);
        TextView name = (TextView) view.findViewById(R.id.name);
        TextView roll = (TextView) view.findViewById(R.id.roll);
        TextView status = (TextView) view.findViewById(R.id.status);
        TextView year= (TextView) view.findViewById(R.id.year);
        TextView date = (TextView) view.findViewById(R.id.date);

        ImageView open=(ImageView) view.findViewById(R.id.open);
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(),PassStatusActivity.class);
                i.putExtra("yr",obj.getYr());
                i.putExtra("roll",obj.getRoll());
                i.putExtra("name",obj.getName());
                i.putExtra("sts",obj.getSts());
                i.putExtra("id",obj.getId());
                i.putExtra("path",obj.getPath());
                i.putExtra("dept",obj.getDept());
                i.putExtra("leaveId",obj.getLeaveId());
                getContext().startActivity(i);
            }
        });

        name.setText(obj.getName());
        roll.setText(obj.getRoll());
        status.setText(obj.getSts());
        year.setText(obj.getYr());
        date.setText(obj.getDate());

        return view;
    }

}