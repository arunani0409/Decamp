package com.example.kcet;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PassApproveActivity extends AppCompatActivity {

    private String ph1="",ph2="",remark="",mUser,tym="",mName,leaveId="";
    private TextView name,roll,reason,start,year,time,leave;
    private SharedPreferences prefs;
    public ProgressDialog progressDialog;
    private Intent i;
    SimpleDateFormat f_year = new SimpleDateFormat("yy");
    SimpleDateFormat f_mon = new SimpleDateFormat("MM");
    SimpleDateFormat f_day = new SimpleDateFormat("dd");
    SimpleDateFormat f_hour = new SimpleDateFormat("HH");
    SimpleDateFormat f_min = new SimpleDateFormat("mm");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_approve);
        time();
        i=getIntent();
        name=findViewById(R.id.name);
        roll=findViewById(R.id.roll);
        start=findViewById(R.id.start);
        time=findViewById(R.id.time);
        year=findViewById(R.id.year);
        leave=findViewById(R.id.leave);
        reason=findViewById(R.id.reason);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");
        mName = prefs.getString("name", "");

        Button callStd=findViewById(R.id.callStd);
        Button callParent=findViewById(R.id.callParent);
        Button approve=findViewById(R.id.approve);
        Button deny=findViewById(R.id.deny);

        load();

        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp(1);
            }
        });

        deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp(2);
            }
        });

        callParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", ph2, null));
                startActivity(intent);
            }
        });
        callStd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", ph1, null));
                startActivity(intent);
            }
        });

        leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PassApproveActivity.this,LeaveStatusActivity.class);
                intent.putExtra("yr",i.getStringExtra("yr"));
                intent.putExtra("roll",i.getStringExtra("roll"));
                intent.putExtra("sts","Leave Approved");
                intent.putExtra("id",i.getStringExtra("leaveId"));
                intent.putExtra("dept",i.getStringExtra("dept"));
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }

    private void popUp(int i) {
        View alertCustomdialog = LayoutInflater.from(PassApproveActivity.this).inflate(R.layout.alert_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(PassApproveActivity.this);
        alert.setView(alertCustomdialog);
        //init views

        Button ok = alertCustomdialog.findViewById(R.id.ok);
        Button cancel = alertCustomdialog.findViewById(R.id.cancel);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        EditText m = alertCustomdialog.findViewById(R.id.msg);

        //setting data
        if(i==1)
        {
            ok.setText("Approve");
            ok.setBackgroundColor(getResources().getColor(R.color.green));
        }
        else
        {
            ok.setText("Deny");
            ok.setBackgroundColor(getResources().getColor(R.color.red));
        }
        t.setText("Remarks?");
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp=m.getText().toString();
                if(temp.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter the remarks!", Toast.LENGTH_LONG).show();
                    m.requestFocus();
                }
                else
                {
                    writeDate(temp,i);
                    dialog.dismiss();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }

    private void writeDate(String remark,int sts)
    {
        progressDialog= ProgressDialog.show(PassApproveActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        //updating pass
        DatabaseReference pass = FirebaseDatabase.getInstance().getReference("Pass/"+i.getStringExtra("path")).child(i.getStringExtra("roll")).child(i.getStringExtra("id"));
        DatabaseReference scoreRef = pass.child("update");
        scoreRef.child("name").setValue(mName);
        scoreRef.child("remark").setValue(remark);
        if(sts==1)
        {
            scoreRef.child("status").setValue("Approved");
            pass.child("status").setValue("Pass Approved");
            pass.child("out").setValue("null");
            pass.child("in").setValue("null");
        }
        else
        {
            scoreRef.child("status").setValue("Rejected");
            pass.child("status").setValue("Pass Rejected");
        }
        scoreRef.child("time").setValue(tym);

        DatabaseReference pending = FirebaseDatabase.getInstance().getReference("PassPending/"+i.getStringExtra("path")).child(i.getStringExtra("id"));
        pending.setValue(null);

        Toast.makeText(PassApproveActivity.this,"Response submitted!",Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    public void time() {
        DatabaseReference offsetRef = FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset");
        offsetRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long offset = snapshot.getValue(long.class);
                long estimatedServerTimeMs = System.currentTimeMillis() + offset;
                String year = f_year.format(new Date(estimatedServerTimeMs));
                String mon = f_mon.format(new Date(estimatedServerTimeMs));
                String day = f_day.format(new Date(estimatedServerTimeMs));
                tym=day+"-"+mon+"-"+year+" "+f_hour.format(new Date(estimatedServerTimeMs))+":"+f_min.format(new Date(estimatedServerTimeMs));
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }


    private void load()
    {
        progressDialog= ProgressDialog.show(PassApproveActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(i.getStringExtra("roll"));
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ph1=dataSnapshot.child("phno").getValue().toString();
                    ph2=dataSnapshot.child("parent_no").getValue().toString();
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);

        DatabaseReference pass = FirebaseDatabase.getInstance().getReference("Pass/"+i.getStringExtra("path"));
        Query scoreRef = pass.child(i.getStringExtra("roll")).child(i.getStringExtra("id"));

        ValueEventListener eventListener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name.setText(dataSnapshot.child("name").getValue().toString());
                    roll.setText(i.getStringExtra("roll"));
                    time.setText(dataSnapshot.child("time").getValue().toString());
                    start.setText(dataSnapshot.child("date").getValue().toString());
                    reason.setText(dataSnapshot.child("reason").getValue().toString());
                    year.setText(i.getStringExtra("yr")+" / "+prefs.getString("dept",""));
                    leaveId=dataSnapshot.child("leaveId").getValue().toString();
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found. Contact Admin!", Snackbar.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        scoreRef.addListenerForSingleValueEvent(eventListener1);
    }
}