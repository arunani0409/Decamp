package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;

public class PassStatusActivity extends AppCompatActivity {

    private String[] mArr=new String[4];
    private TextView name,roll,reason,start,end,status,year,time,r1,r2;
    public ProgressDialog progressDialog;
    public Bitmap bitmap;
    private Intent i;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_status);

        i=getIntent();
        name=findViewById(R.id.name);
        roll=findViewById(R.id.roll);
        start=findViewById(R.id.start);
        end=findViewById(R.id.end);
        time=findViewById(R.id.time);
        year=findViewById(R.id.year);
        status=findViewById(R.id.status);
        reason=findViewById(R.id.reason);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Remarks",mArr);
            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PassStatusActivity.this,LeaveStatusActivity.class);
                intent.putExtra("yr",i.getStringExtra("yr"));
                intent.putExtra("roll",i.getStringExtra("roll"));
                intent.putExtra("sts","Leave Approved");
                intent.putExtra("id",i.getStringExtra("leaveId"));
                intent.putExtra("dept",i.getStringExtra("dept"));
                startActivity(intent);
            }
        });

        load();
        if(i.getStringExtra("sts").equals("Pass Approved"))
        {
            GifImageView gifImageView = (GifImageView) findViewById(R.id.gif);
            gifImageView.setImageResource(R.drawable.approval_gif);
        }
        else if(i.getStringExtra("sts").equals("Pass Rejected"))
        {
            GifImageView gifImageView = (GifImageView) findViewById(R.id.gif);
            gifImageView.setImageResource(R.drawable.reject_gif);
        }
    }

    @Override
    protected void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }


    private void load()
    {
        progressDialog= ProgressDialog.show(PassStatusActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference userNameRef1 = FirebaseDatabase.getInstance().getReference("Pass/"+i.getStringExtra("path")).child(i.getStringExtra("roll")).child(i.getStringExtra("id"));
        ValueEventListener eventListener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name.setText(dataSnapshot.child("name").getValue().toString());
                    roll.setText(i.getStringExtra("roll"));
                    time.setText(dataSnapshot.child("time").getValue().toString());
                    if(dataSnapshot.child("status").getValue().toString().equals("Pass Rejected"))
                    {
                        start.setVisibility(View.GONE);
                        end.setVisibility(View.GONE);
                        TextView out=findViewById(R.id.out);
                        TextView in=findViewById(R.id.in);
                        out.setVisibility(View.GONE);
                        in.setVisibility(View.GONE);
                    }
                    else
                    {
                        String path="Pass/"+i.getStringExtra("path")+"/"+(i.getStringExtra("roll")+"/"+(i.getStringExtra("id")));
//                        start.setText((dataSnapshot.child("out").getValue().toString().equals("null")?"Not yet out":dataSnapshot.child("out").getValue().toString()));
//                        end.setText((dataSnapshot.child("in").getValue().toString().equals("null")?"Not yet in":dataSnapshot.child("in").getValue().toString()));;
//                        try {
//                            generateQR();
//                        } catch (WriterException e) {
//                            e.printStackTrace();
//                        }
                        if(dataSnapshot.child("out").getValue().toString().equals("null"))
                        {
                            start.setText("Show QR Code");
                            start.setTextColor(getResources().getColor(R.color.green));
                            try {
                                generateQR(path+"/out");
                            } catch (WriterException e) {
                                e.printStackTrace();
                            }
                            start.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    qrPop("QR Code for Out Pass");
                                }
                            });
                        }
                        else
                        {
                            start.setText(dataSnapshot.child("out").getValue().toString());
                            start.setTextColor(getResources().getColor(R.color.red));
                        }

                        if(dataSnapshot.child("in").getValue().toString().equals("null"))
                        {
                            end.setText("Show QR Code");
                            end.setTextColor(getResources().getColor(R.color.green));
                            try {
                                generateQR(path+"/in");
                            } catch (WriterException e) {
                                e.printStackTrace();
                            }
                            end.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    qrPop("QR Code for In Pass");
                                }
                            });
                        }
                        else
                        {
                            end.setText(dataSnapshot.child("in").getValue().toString());
                            end.setTextColor(getResources().getColor(R.color.red));
                        }
                    }
                    reason.setText(dataSnapshot.child("reason").getValue().toString());
                    status.setText(dataSnapshot.child("status").getValue().toString());
                    year.setText(i.getStringExtra("yr")+" / "+prefs.getString("dept",""));
                    mArr[0]=dataSnapshot.child("update/name").getValue().toString();
                    mArr[3]=dataSnapshot.child("update/status").getValue().toString();
                    mArr[2]=dataSnapshot.child("update/time").getValue().toString();
                    mArr[1]=dataSnapshot.child("update/remark").getValue().toString();
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found. Contact Admin!", Snackbar.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef1.addListenerForSingleValueEvent(eventListener1);
    }

    private void remarkPop(String title, String[] arr) {
        View alertCustomdialog = LayoutInflater.from(PassStatusActivity.this).inflate(R.layout.remarks_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(PassStatusActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView name = alertCustomdialog.findViewById(R.id.name);
        TextView remark = alertCustomdialog.findViewById(R.id.remark);
        TextView time = alertCustomdialog.findViewById(R.id.time);
        TextView status = alertCustomdialog.findViewById(R.id.status);
        //setting data
        if(arr[3].equals("Approved"))
            status.setTextColor(getResources().getColor(R.color.green));
        else
            status.setTextColor(getResources().getColor(R.color.red));
        t.setText(title);
        name.setText(arr[0]);
        remark.setText(arr[1]);
        status.setText(arr[3]);
        time.setText(arr[2]);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss(); }
        });
    }

    private void generateQR(String path) throws WriterException {
        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix bitMatrix = writer.encode(path, BarcodeFormat.QR_CODE, 512, 512);
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        bitmap= Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }
    }

    private void qrPop(String title) {
        View alertCustomdialog = LayoutInflater.from(PassStatusActivity.this).inflate(R.layout.qr_popup, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(PassStatusActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        ImageView code = alertCustomdialog.findViewById(R.id.code);
        //setting data
        code.setImageBitmap(bitmap);
        t.setText(title);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss(); }
        });
    }
}