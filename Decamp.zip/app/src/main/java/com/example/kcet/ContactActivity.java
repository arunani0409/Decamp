package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ContactActivity extends AppCompatActivity {

    private String m,cp,hod;
    private ImageView i1,i2,i3;
    private TextView t1,t2,t3,m1,m2,m3;
    public ProgressDialog progressDialog;
    private Button b1,b2,b3;
    public Intent intent;
    public SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        i1=findViewById(R.id.photo1);
        i2=findViewById(R.id.photo2);
        i3=findViewById(R.id.photo3);

        t1=findViewById(R.id.name1);
        t2=findViewById(R.id.name2);
        t3=findViewById(R.id.name3);

        m1=findViewById(R.id.mail1);
        m2=findViewById(R.id.mail2);
        m3=findViewById(R.id.mail3);

        b1=findViewById(R.id.c1);
        b2=findViewById(R.id.c2);
        b3=findViewById(R.id.c3);

        progressDialog = ProgressDialog.show(ContactActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(prefs.getString("roll_no",""));
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    getData(dataSnapshot.child("mentor").getValue().toString(),1);
                    getData(dataSnapshot.child("chairperson").getValue().toString(),2);
                    getData(dataSnapshot.child("hod").getValue().toString(),3);
                }
                else
                    Snackbar.make(findViewById(R.id.parent), "Data not found!", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", m, null));
                startActivity(intent);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", cp, null));
                startActivity(intent);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", hod, null));
                startActivity(intent);
            }
        });

        m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent= new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:")); // only email apps should handle this
                intent.putExtra(Intent.EXTRA_EMAIL,m1.getText());
                startActivity(intent);
            }
        });

        m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent= new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:")); // only email apps should handle this
                intent.putExtra(Intent.EXTRA_EMAIL,m2.getText());
                startActivity(intent);
            }
        });

        m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent= new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:")); // only email apps should handle this
                intent.putExtra(Intent.EXTRA_EMAIL,m3.getText());
                startActivity(intent);
            }
        });

    }

    private void getData(String staff,int i)
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StaffData").child(prefs.getString("dept","")).child(staff);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    switch (i)
                    {
                        case 1:
                            m=dataSnapshot.child("phno").getValue().toString();
                            t1.setText(dataSnapshot.child("name").getValue().toString());
                            m1.setText(dataSnapshot.child("mail").getValue().toString());
                            load(staff,i);
                            break;
                        case 2:
                            cp=dataSnapshot.child("phno").getValue().toString();
                            t2.setText(dataSnapshot.child("name").getValue().toString());
                            m2.setText(dataSnapshot.child("mail").getValue().toString());
                            load(staff,i);
                            break;
                        case 3:
                            hod=dataSnapshot.child("phno").getValue().toString();
                            t3.setText(dataSnapshot.child("name").getValue().toString());
                            m3.setText(dataSnapshot.child("mail").getValue().toString());
                            load(staff,i);
                            break;
                    }
                }
                else
                    Snackbar.make(findViewById(R.id.parent), "Data not found!", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }

    private void load(String staff,int i)
    {
        final long ONE_MEGABYTE = 1024 * 1024;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("/"+staff+".jpg");

        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                switch (i)
                {
                    case 1:
                        i1.setImageBitmap(bmp);
                        break;
                    case 2:
                        i2.setImageBitmap(bmp);
                        break;
                    case 3:
                        i3.setImageBitmap(bmp);
                        progressDialog.dismiss();
                        break;
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });
    }

}