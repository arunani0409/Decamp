package com.example.kcet;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class LeaveStsFragment extends Fragment {

    ArrayList<LeaveStsList> list = new ArrayList<>();
    public String mUser,yr,dept,sts;
    public TextView no_data;
    View view;
    public String[] arr;
    public int i=0,j;
    public boolean fl=false,user;
    public ProgressDialog progressDialog;
    public LeaveStsFragment(String mUser, String yr, String dept, String sts,boolean user){
        this.mUser=mUser;this.yr=yr;this.dept=dept;this.sts=sts;this.user=user;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_leave_pending, container, false);
        no_data=view.findViewById(R.id.no_data);

        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        if(user)
        {
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Leave/"+dept+"/"+yr);
            Query scoreRef = rootRef.child(mUser);
                ValueEventListener eventListener = new ValueEventListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for(DataSnapshot ds:dataSnapshot.getChildren())
                            {
                                if(ds.child("status").getValue().toString().equals(sts))
                                {
                                    list.add(new LeaveStsList(ds.child("name").getValue().toString(), ds.child("status").getValue().toString(), yr,dataSnapshot.getKey(),ds.getKey(),ds.child("type").getValue().toString(),ds.child("startD").getValue().toString(),ds.child("endD").getValue().toString()));
                                    update();
                                }
                            }
                            if(list.isEmpty())
                            {
                                no_data.setText("No records found.");
                                no_data.setVisibility(View.VISIBLE);
                            }
                        }
                        else
                        {
                            no_data.setText("No records found.");
                            no_data.setVisibility(View.VISIBLE);
                        }
                        progressDialog.dismiss();
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity(),"Something went wrong.",Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();}
                };
                scoreRef.addListenerForSingleValueEvent(eventListener);
        }
        else
        {
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("DeptData/"+dept+"/"+yr);
            ValueEventListener eventListener = new ValueEventListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        arr=new String[(int)dataSnapshot.getChildrenCount()];
                        if(dataSnapshot.child("hod").getValue().toString().equals(mUser)||dataSnapshot.child("cp").getValue().toString().equals(mUser))
                        {
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                if(!ds.getKey().equals("hod")&&!ds.getKey().equals("cp"))
                                {
                                    arr[i]=ds.getKey();
                                    i++;
                                }
                                if(ds.getKey().equals("cp"))
                                    getData(arr);
                            }
                        }
                        else
                        {
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                if(!ds.getKey().equals("hod")&&!ds.getKey().equals("cp"))
                                {
                                    if(ds.getValue().toString().equals(mUser))
                                    {
                                        arr[i]=ds.getKey();
                                        i++;
                                    }
                                }
                                if(ds.getKey().equals("cp"))
                                    getData(arr);
                            }
                        }
                        progressDialog.dismiss();
                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(getActivity(),"No data found. Contact Admin!",Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {}
            };
            rootRef.addListenerForSingleValueEvent(eventListener);
        }

        return view;
    }


    private void getData(String roll[])
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Leave/"+dept+"/"+yr);
        for(j=0;j<i;j++)
        {
            Query scoreRef = rootRef.child(roll[j]);
            ValueEventListener eventListener = new ValueEventListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for(DataSnapshot ds:dataSnapshot.getChildren())
                        {
                            if(ds.child("status").getValue().toString().equals(sts))
                            {
                                list.add(new LeaveStsList(ds.child("name").getValue().toString(), ds.child("status").getValue().toString(), yr,dataSnapshot.getKey(),ds.getKey(),ds.child("type").getValue().toString(),ds.child("startD").getValue().toString(),ds.child("endD").getValue().toString()));
                                update();
                            }
                        }
                        return;
                    }
                    else
                    {
                        no_data.setText("No records found.");
                        no_data.setVisibility(View.VISIBLE);
                    }

                }
                @Override
                public void onCancelled(DatabaseError databaseError) {progressDialog.dismiss();}
            };
            scoreRef.addListenerForSingleValueEvent(eventListener);
        }
    }

    private void update()
    {
        if (list.isEmpty())
        {
            no_data.setText("No records found.");
            no_data.setVisibility(View.VISIBLE);
        }
        else
            no_data.setVisibility(View.GONE);

        if (getActivity()!=null) {
            LeaveStsListAdapter adaptor = new LeaveStsListAdapter(getActivity(), list);
            ListView listView = (ListView) view.findViewById(R.id.list);

            listView.setAdapter(adaptor);
        }
        progressDialog.dismiss();
    }

}