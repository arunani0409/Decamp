package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LeaveApproveActivity extends AppCompatActivity {

    private String ph1="",ph2="",remark="",mUser,tym="",mName,mentor="",cp="",hod="";
    private String[] mArr=new String[4],cArr=new String[4],hArr=new String[4];
    private TextView name,roll,reason,start,end,days,year,type,time,r1,r2,r3;
    private SharedPreferences prefs;
    public ProgressDialog progressDialog;
    private Intent i;
    SimpleDateFormat f_year = new SimpleDateFormat("yy");
    SimpleDateFormat f_mon = new SimpleDateFormat("MM");
    SimpleDateFormat f_day = new SimpleDateFormat("dd");
    SimpleDateFormat f_hour = new SimpleDateFormat("HH");
    SimpleDateFormat f_min = new SimpleDateFormat("mm");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_approve);
        time();
        i=getIntent();
        name=findViewById(R.id.name);
        roll=findViewById(R.id.roll);
        start=findViewById(R.id.start);
        end=findViewById(R.id.end);
        time=findViewById(R.id.time);
        year=findViewById(R.id.year);
        type=findViewById(R.id.type);
        reason=findViewById(R.id.reason);
        days=findViewById(R.id.days);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);

        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");
        mName = prefs.getString("name", "");

        Button callStd=findViewById(R.id.callStd);
        Button callParent=findViewById(R.id.callParent);
        Button approve=findViewById(R.id.approve);
        Button deny=findViewById(R.id.deny);

        load();

        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp(1);
            }
        });

        deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp(2);
            }
        });

        callParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", ph2, null));
                startActivity(intent);
            }
        });
        callStd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", ph1, null));
                startActivity(intent);
            }
        });

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Mentor's Remarks",mArr);
            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("Chairperson's Remarks",cArr);
            }
        });

        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remarkPop("HoD's Remarks",hArr);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }

    private void popUp(int i) {
        View alertCustomdialog = LayoutInflater.from(LeaveApproveActivity.this).inflate(R.layout.alert_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(LeaveApproveActivity.this);
        alert.setView(alertCustomdialog);
        //init views

        Button ok = alertCustomdialog.findViewById(R.id.ok);
        Button cancel = alertCustomdialog.findViewById(R.id.cancel);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        EditText m = alertCustomdialog.findViewById(R.id.msg);

        //setting data
        if(i==1)
        {
            ok.setText("Approve");
            ok.setBackgroundColor(getResources().getColor(R.color.green));
        }
        else
        {
            ok.setText("Deny");
            ok.setBackgroundColor(getResources().getColor(R.color.red));
        }
        t.setText("Remarks?");
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp=m.getText().toString();
                if(temp.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter the remarks!", Toast.LENGTH_LONG).show();
                    m.requestFocus();
                }
                else
                {
                    writeDate(temp,i);
                    dialog.dismiss();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }

    private void writeDate(String remark,int sts)
    {
        progressDialog= ProgressDialog.show(LeaveApproveActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference leaveNode = FirebaseDatabase.getInstance().getReference().child("Leave").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(i.getStringExtra("roll")).child(i.getStringExtra("id"));
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference pendingSource = rootRef.child("LeavePending").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(mUser).child(i.getStringExtra("id"));

        //mentor & cp update
        if(mUser.equals(cp)&&mUser.equals(mentor))
        {
            DatabaseReference m=leaveNode.child("mentor");
            m.child("name").setValue(mName);
            m.child("remark").setValue(remark);
            m.child("time").setValue(tym);
            m.child("status").setValue("Approved");
            leaveNode.child("level").setValue(1);

            if(sts==1)
            {
                DatabaseReference c=leaveNode.child("cp");
                c.child("name").setValue(mName);
                c.child("remark").setValue(remark);
                c.child("time").setValue(tym);
                c.child("status").setValue("Approved");
                leaveNode.child("level").setValue(2);
                leaveNode.child("status").setValue("Chairperson Approved");

                ValueEventListener eventListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            DatabaseReference rootRef1 = FirebaseDatabase.getInstance().getReference().child("LeavePending").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(hod).child(i.getStringExtra("id"));
                            rootRef1.setValue(dataSnapshot.getValue());
                            pendingSource.setValue(null);
                        }
                        else {
                            Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        progressDialog.dismiss();
                        Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
                    }
                };
                pendingSource.addListenerForSingleValueEvent(eventListener);
            }
            else
            {
                pendingSource.setValue(null);
                m.child("status").setValue("Rejected");
                leaveNode.child("status").setValue("Leave Rejected");
            }
        }
        //hod update
        else if(mUser.equals(hod)){
            DatabaseReference m=leaveNode.child("hod");
            m.child("name").setValue(mName);
            m.child("remark").setValue(remark);
            m.child("time").setValue(tym);
            leaveNode.child("level").setValue(3);

            if (sts == 1) {
                m.child("status").setValue("Approved");
                leaveNode.child("status").setValue("Leave Approved");
                pendingSource.setValue(null);
            } else {
                pendingSource.setValue(null);
                m.child("status").setValue("Rejected");
                leaveNode.child("status").setValue("Leave Rejected");
            }
        }

        //cp update
        else if(mUser.equals(cp))
        {
            DatabaseReference c=leaveNode.child("cp");
            c.child("name").setValue(mName);
            c.child("remark").setValue(remark);
            c.child("time").setValue(tym);
            leaveNode.child("level").setValue(2);
            if (sts == 1) {
                c.child("status").setValue("Approved");
                leaveNode.child("status").setValue("Chairperson Approved");
                ValueEventListener eventListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            DatabaseReference rootRef1 = FirebaseDatabase.getInstance().getReference().child("LeavePending").child(prefs.getString("dept", "")).child(i.getStringExtra("yr")).child(hod).child(i.getStringExtra("id"));
                            rootRef1.setValue(dataSnapshot.getValue());
                            pendingSource.setValue(null);
                        } else {
                            Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        progressDialog.dismiss();
                        Snackbar.make(findViewById(R.id.parent), "Something went wrong!" + databaseError, Snackbar.LENGTH_SHORT).show();
                    }
                };
                pendingSource.addListenerForSingleValueEvent(eventListener);
            } else {
                pendingSource.setValue(null);
                c.child("status").setValue("Rejected");
                leaveNode.child("status").setValue("Leave Rejected");
            }
        }

        //mentor update
        else {
            DatabaseReference m = leaveNode.child("mentor");
            m.child("name").setValue(mName);
            m.child("remark").setValue(remark);
            m.child("time").setValue(tym);
            leaveNode.child("level").setValue(1);
            if (sts == 1) {
                m.child("status").setValue("Approved");
                leaveNode.child("status").setValue("Mentor Approved");

                ValueEventListener eventListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            DatabaseReference rootRef1 = FirebaseDatabase.getInstance().getReference().child("LeavePending").child(prefs.getString("dept", "")).child(i.getStringExtra("yr")).child(cp).child(i.getStringExtra("id"));
                            rootRef1.setValue(dataSnapshot.getValue());
                            pendingSource.setValue(null);
                        } else {
                            Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        progressDialog.dismiss();
                        Snackbar.make(findViewById(R.id.parent), "Something went wrong!" + databaseError, Snackbar.LENGTH_SHORT).show();
                    }
                };
                pendingSource.addListenerForSingleValueEvent(eventListener);
            } else {
                pendingSource.setValue(null);
                m.child("status").setValue("Rejected");
                leaveNode.child("status").setValue("Leave Rejected");
            }
        }

        Toast.makeText(LeaveApproveActivity.this,"Response submitted!",Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    public void time() {
        DatabaseReference offsetRef = FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset");
        offsetRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long offset = snapshot.getValue(long.class);
                long estimatedServerTimeMs = System.currentTimeMillis() + offset;
                String year = f_year.format(new Date(estimatedServerTimeMs));
                String mon = f_mon.format(new Date(estimatedServerTimeMs));
                String day = f_day.format(new Date(estimatedServerTimeMs));
                tym=day+"-"+mon+"-"+year+" "+f_hour.format(new Date(estimatedServerTimeMs))+":"+f_min.format(new Date(estimatedServerTimeMs));
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }


    private void load()
    {
        progressDialog= ProgressDialog.show(LeaveApproveActivity.this,null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(i.getStringExtra("roll"));
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ph1=dataSnapshot.child("phno").getValue().toString();
                    ph2=dataSnapshot.child("parent_no").getValue().toString();
                    hod=dataSnapshot.child("hod").getValue().toString();
                    cp=dataSnapshot.child("chairperson").getValue().toString();
                    mentor=dataSnapshot.child("mentor").getValue().toString();
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found! Contact Admin", Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);

        DatabaseReference rootRef1 = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef1 = rootRef1.child("Leave").child(prefs.getString("dept","")).child(i.getStringExtra("yr")).child(i.getStringExtra("roll")).child(i.getStringExtra("id"));
        ValueEventListener eventListener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name.setText(dataSnapshot.child("name").getValue().toString());
                    roll.setText(i.getStringExtra("roll"));
                    time.setText(dataSnapshot.child("time").getValue().toString());
                    start.setText(dataSnapshot.child("startD").getValue().toString()+" ("+dataSnapshot.child("startS").getValue().toString()+")");
                    end.setText(dataSnapshot.child("endD").getValue().toString()+" ("+dataSnapshot.child("endS").getValue().toString()+")");
                    reason.setText(dataSnapshot.child("reason").getValue().toString());
                    days.setText(dataSnapshot.child("days").getValue().toString());
                    type.setText(dataSnapshot.child("type").getValue().toString());
                    year.setText(i.getStringExtra("yr")+" / "+prefs.getString("dept",""));
                    switch (dataSnapshot.child("level").getValue().toString())
                    {
                        case "0":
                            r1.setVisibility(View.GONE);
                            r2.setVisibility(View.GONE);
                            r3.setVisibility(View.GONE);
                            break;
                        case "1":
                            r2.setVisibility(View.GONE);
                            r3.setVisibility(View.GONE);

                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();
                            break;
                        case "2":
                            r3.setVisibility(View.GONE);

                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                            cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                            cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();
                            break;
                        case "3":
                            mArr[0]=dataSnapshot.child("mentor/name").getValue().toString();mArr[1]=dataSnapshot.child("mentor/remark").getValue().toString();
                            mArr[2]=dataSnapshot.child("mentor/time").getValue().toString();mArr[3]=dataSnapshot.child("mentor/status").getValue().toString();

                            cArr[0]=dataSnapshot.child("cp/name").getValue().toString();cArr[1]=dataSnapshot.child("cp/remark").getValue().toString();
                            cArr[2]=dataSnapshot.child("cp/time").getValue().toString();cArr[3]=dataSnapshot.child("cp/status").getValue().toString();

                            hArr[0]=dataSnapshot.child("hod/name").getValue().toString();hArr[1]=dataSnapshot.child("hod/remark").getValue().toString();
                            hArr[2]=dataSnapshot.child("hod/time").getValue().toString();hArr[3]=dataSnapshot.child("hod/status").getValue().toString();
                            break;
                    }
                }
                else {
                    Snackbar.make(findViewById(R.id.parent), "Data not found. Contact Admin!", Snackbar.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef1.addListenerForSingleValueEvent(eventListener1);
    }

    private void remarkPop(String title, String[] arr) {
        View alertCustomdialog = LayoutInflater.from(LeaveApproveActivity.this).inflate(R.layout.remarks_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(LeaveApproveActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView name = alertCustomdialog.findViewById(R.id.name);
        TextView remark = alertCustomdialog.findViewById(R.id.remark);
        TextView time = alertCustomdialog.findViewById(R.id.time);
        TextView status = alertCustomdialog.findViewById(R.id.status);
        //setting data
        if(arr[3].equals("Approved"))
            status.setTextColor(getResources().getColor(R.color.green));
        else
            status.setTextColor(getResources().getColor(R.color.red));
        t.setText(title);
        name.setText(arr[0]);
        remark.setText(arr[1]);
        status.setText(arr[3]);
        time.setText(arr[2]);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss(); }
        });
    }
}