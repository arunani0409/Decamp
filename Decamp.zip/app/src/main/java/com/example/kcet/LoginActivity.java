package com.example.kcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private String mUser="",mPass="";
    public ProgressDialog progressDialog;
    private EditText user,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        user=findViewById(R.id.roll);
        pass=findViewById(R.id.password);

        Button button=findViewById(R.id.create);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUser=user.getText().toString();
                mPass=pass.getText().toString();
                if(verifyUser())
                {
                    if (verifyPass())
                        getRef();
                }
            }
        });

        TextView login=findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(LoginActivity.this,LoginActivity2.class);
                startActivity(i);
            }
        });
    }

    private boolean verifyUser() {
        if (mUser.isEmpty()||mUser.length()<9||mUser.matches("[.!@#$%&*()_+=|<>?{}\\[\\]~-]")||mUser.length()>9)
        {
            Snackbar.make(findViewById(R.id.parent),"Invalid Roll number",Snackbar.LENGTH_SHORT).show();
            user.requestFocus();
            return false;
        }
        return true;
    }

    private boolean verifyPass() {
        if (mPass.isEmpty()){
            pass.requestFocus();
            Snackbar.make(findViewById(R.id.parent),"Enter password",Snackbar.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void getRef()
    {
        progressDialog = ProgressDialog.show(LoginActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("Reference/std").child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()) {
                    //create new user
                    Snackbar.make(findViewById(R.id.parent),"Roll No not found. Please contact the admin!",Snackbar.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
                else {
                    onSuccess(dataSnapshot.child("dept").getValue().toString(),dataSnapshot.child("year").getValue().toString(),dataSnapshot.child("stay").getValue().toString(),dataSnapshot.child("gender").getValue().toString());

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }

    private void onSuccess(String dept,String yr,String stay,String gender) {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("Login/std").child(dept).child(yr).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    if (dataSnapshot.getValue().toString().equals(mPass)) {
                        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("roll_no", mUser);
                        editor.putString("dept", dept);
                        editor.putString("yr", yr);
                        editor.putString("stay", stay);
                        editor.putString("gender", gender);
                        editor.apply();
                        progressDialog.dismiss();
                        Intent intent = new Intent(LoginActivity.this, StdActivity.class);
                        startActivity(intent);
                    } else {
                        progressDialog.dismiss();
                        Snackbar.make(findViewById(R.id.parent), "Incorrect password", Snackbar.LENGTH_SHORT).show();
                        pass.setText("");pass.requestFocus();
                    }
                }
                else {
                    progressDialog.dismiss();
                    Snackbar.make(findViewById(R.id.parent), "User not found. Contact Admin!", Snackbar.LENGTH_SHORT).show();
                    pass.setText("");pass.requestFocus();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus()!=null){
            InputMethodManager inputManager=(InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),0);
            user.clearFocus();
            pass.clearFocus();
        }
        return super.dispatchTouchEvent(ev);
    }

}