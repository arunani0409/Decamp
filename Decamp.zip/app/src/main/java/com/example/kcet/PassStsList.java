package com.example.kcet;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class PassStsList
{
    public String name;
    public String sts;
    public String yr;
    public String roll;
    public String id;
    public String dept;
    public String date;
    public String leaveId;
    public String path;

    DateFormat formatter1=new SimpleDateFormat("dd/MM/yy");

    public PassStsList(String name, String sts, String yr, String roll, String id, String dept, String date, String leaveId,String path)
    {
        this.name=name;
        this.sts=sts;
        this.yr=yr;
        this.roll=roll;
        this.id=id;
        this.dept=dept;
        this.date=date;
        this.leaveId=leaveId;
        this.path=path;
    }

    public String getName(){return name;}
    public String getSts(){return sts;}
    public String getYr(){return yr;}
    public String getId(){return id;}
    public String getRoll(){return roll;}
    public String getDept(){return dept;}
    public String getDate(){return date;}
    public String getPath(){return path;}
    public String getLeaveId(){return leaveId;}

}
