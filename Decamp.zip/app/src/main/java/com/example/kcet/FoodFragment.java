package com.example.kcet;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FoodFragment extends Fragment {

    ArrayList<FoodList> list = new ArrayList<>();
    public String path;
    public TextView no_data;
    View view;
    public ProgressDialog progressDialog;
    public FoodFragment(String path) {
        this.path=path;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_leave_pending, container, false);
        no_data=view.findViewById(R.id.no_data);

        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference(path);
        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot ds) {
                if (ds.exists()) {
                    for(DataSnapshot dataSnapshot: ds.getChildren())
                    {
                        list.add(new FoodList(dataSnapshot.getKey(), dataSnapshot.getValue().toString()));
                    }

                    if (list.isEmpty())
                    {
                        no_data.setText("No Food Item");
                        no_data.setVisibility(View.VISIBLE);
                    }
                    else
                        no_data.setVisibility(View.GONE);

                    if (getActivity()!=null) {
                        FoodListAdapter adaptor = new FoodListAdapter(getActivity(), list);
                        ListView listView = (ListView) view.findViewById(R.id.list);

                        listView.setAdapter(adaptor);
                        progressDialog.dismiss();
                    }
                    progressDialog.dismiss();
                    return;
                }
                else {
                    no_data.setText("No Food Item");
                    no_data.setVisibility(View.VISIBLE);
                    progressDialog.dismiss();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        };
        rootRef.addListenerForSingleValueEvent(eventListener);
        return view;
    }

}