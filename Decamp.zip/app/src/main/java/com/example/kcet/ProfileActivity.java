package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Date;

public class ProfileActivity extends AppCompatActivity {

    private ImageView image;
    public ProgressDialog progressDialog;
    private String mUser="";
    private TextView name,dept,yr,parent_name,parent_no,phno,mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name=findViewById(R.id.name);
        dept=findViewById(R.id.dept);
        yr=findViewById(R.id.yr);
        parent_name=findViewById(R.id.parent_name);
        parent_no=findViewById(R.id.parent_no);
        phno=findViewById(R.id.phno);
        mail=findViewById(R.id.mail);

        load();
    }

    private void load()
    {
        progressDialog = ProgressDialog.show(ProfileActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");

        final long ONE_MEGABYTE = 1024 * 1024;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("/"+mUser+".jpg");
        image=findViewById(R.id.image);
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                image.setImageBitmap(bmp);
                progressDialog.dismiss();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name.setText(prefs.getString("name",""));
                    yr.setText(prefs.getString("yr",""));
                    dept.setText(prefs.getString("dept",""));
                    mail.setText(dataSnapshot.child("mail").getValue().toString());
                    parent_name.setText(dataSnapshot.child("parent").getValue().toString());
                    parent_no.setText(dataSnapshot.child("parent_no").getValue().toString());
                    phno.setText(dataSnapshot.child("phno").getValue().toString());
                }
                else
                    Snackbar.make(findViewById(R.id.parent), "data not found!", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.parent), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }
}