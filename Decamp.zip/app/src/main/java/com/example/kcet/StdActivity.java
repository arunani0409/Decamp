package com.example.kcet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.internal.NavigationMenuView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class StdActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private NavigationView navigationView;
    public DrawerLayout drawerLayout;
    private TextView name;
    private ImageView imageView;
    public ProgressDialog progressDialog;
    private String mUser="";
    public Intent intent;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_std);


        prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);

        navigationView = findViewById(R.id.navigation_view);
        NavigationMenuView navigationMenu = (NavigationMenuView) navigationView.getChildAt(0);
        navigationMenu.setVerticalScrollBarEnabled(false);
        drawerLayout = findViewById(R.id.drawer);

        ImageView opener = findViewById(R.id.person);
        opener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        name=findViewById(R.id.name);
        imageView=findViewById(R.id.person);

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();

        load();

        LinearLayout l1=findViewById(R.id.l1);
        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent=new Intent(StdActivity.this,LeaveApplyActivity.class);
                startActivity(intent);
            }
        });

        LinearLayout l2=findViewById(R.id.l2);
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent=new Intent(StdActivity.this,PassApplyActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent i = null;
        switch (item.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_profile:
                i = new Intent(StdActivity.this, ProfileActivity.class);
                break;
            case R.id.nav_leave:
                i = new Intent(StdActivity.this, LeaveStdActivity.class);
                break;
            case R.id.nav_contact:
                i = new Intent(StdActivity.this, ContactActivity.class);
                break;
            case R.id.nav_fee:
                i = new Intent(StdActivity.this, FeesActivity.class);
                break;
            case R.id.nav_canteen:
                i = new Intent(StdActivity.this, CanteenActivity.class);
                break;
            case R.id.nav_pass:
                i = new Intent(StdActivity.this, PassStdActivity.class);
                break;
//            case R.id.nav_contact:
//                i = new Intent(Intent.ACTION_SENDTO);
//                i.setType("*/*");
//                i.setData(Uri.parse("mailto:"));
//                i.putExtra(Intent.EXTRA_EMAIL, new String[]{"anidigitalcorporation@gmail.com"});
//                i.putExtra(Intent.EXTRA_SUBJECT, "Facing Issue in Adify");
//                break;
//            case R.id.nav_rate:
//                i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.ar.lens"));
//                break;
            case R.id.nav_out:
                popUp("Warning!","Are you sure want to logout?","STAY","LOGOUT",new Intent(StdActivity.this,LoginActivity.class));
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        if (i != null)
            startActivity(i);
        return false;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isOpen())
            drawerLayout.closeDrawer(GravityCompat.START);
        else
            finishAffinity();
    }

    private void popUp(String title, String msg, String b1, String b2, Intent i) {
        View alertCustomdialog = LayoutInflater.from(StdActivity.this).inflate(R.layout.popup_dialog, null);
        AlertDialog.Builder alert = new AlertDialog.Builder(StdActivity.this);
        alert.setView(alertCustomdialog);
        //init views
        Button cancel = alertCustomdialog.findViewById(R.id.cancel);
        Button ok = alertCustomdialog.findViewById(R.id.ok);
        TextView t = alertCustomdialog.findViewById(R.id.title);
        TextView m = alertCustomdialog.findViewById(R.id.msg);
        //setting data
        cancel.setText(b1);
        ok.setText(b2);
        t.setText(title);
        m.setText(msg);
        //show pop
        final AlertDialog dialog = alert.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.clear();
                editor.commit();
                dialog.dismiss();
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });
    }

    private void load()
    {
        progressDialog = ProgressDialog.show(StdActivity.this, null, null, true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("status", Context.MODE_PRIVATE);
        mUser = prefs.getString("roll_no", "");


        name.setText(mUser);

        final long ONE_MEGABYTE = 1024 * 1024;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("/"+mUser+".jpg");

        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                imageView.setImageBitmap(bmp);
                setDrawerData(bmp);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });
    }

    public void setDrawerData(Bitmap bmp)
    {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userNameRef = rootRef.child("StdData").child(prefs.getString("dept","")).child(prefs.getString("yr","")).child(mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("name", dataSnapshot.child("name").getValue().toString());
                    editor.apply();

                    View header = navigationView.getHeaderView(0);
                    TextView nav_name = header.findViewById(R.id.nav_name);
                    TextView nav_mob = header.findViewById(R.id.nav_mob);
                    ImageView nav_photo=header.findViewById(R.id.nav_person);

                    nav_mob.setText(mUser);
                    nav_name.setText(dataSnapshot.child("name").getValue().toString());
                    nav_photo.setImageBitmap(bmp);
                }
                else
                    Snackbar.make(findViewById(R.id.drawer), "data not found!", Snackbar.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.drawer), "Something went wrong!"+databaseError, Snackbar.LENGTH_SHORT).show();
            }
        };
        userNameRef.addListenerForSingleValueEvent(eventListener);
    }
}