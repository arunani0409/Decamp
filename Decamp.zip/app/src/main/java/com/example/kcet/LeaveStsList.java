package com.example.kcet;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class LeaveStsList
{
    public String name;
    public String sts;
    public String yr;
    public String roll;
    public String id;
    public String type;
    public String start;
    public String end;
    DateFormat formatter1=new SimpleDateFormat("dd/MM/yy");
    public LeaveStsList(String name, String sts, String yr, String roll, String id, String type, String start, String end)
    {
        this.name=name;
        this.sts=sts;
        this.yr=yr;
        this.roll=roll;
        this.id=id;
        this.type=type;
        this.start=start;
        this.end=end;
    }

    public String getName(){return name;}
    public String getSts(){return sts;}
    public String getYr(){return yr;}
    public String getId(){return id;}
    public String getRoll(){return roll;}
    public String getStart(){return start;}
    public Date getDate(){
        Date date= null;
        try {
            date =formatter1.parse(end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
    public String getEnd()
    {
        return end;
    }
    public String getType(){return type;}
}
