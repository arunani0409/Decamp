package com.example.kcet;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

// FirebaseRecyclerAdapter is a class provided by
// FirebaseUI. it provides functions to bind, adapt and show
// database contents in a Recycler View

public class FoodListAdapter extends ArrayAdapter<FoodList> {

    public FoodListAdapter(Activity context, ArrayList<FoodList> words) {
        super(context, 0, words);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.food_list, parent, false);
        }

        FoodList obj = getItem(position);
        TextView item = (TextView) view.findViewById(R.id.item);
        TextView price = (TextView) view.findViewById(R.id.price);

        item.setText("-> "+obj.getName());
        price.setText("₹ "+obj.getPrice());
        return view;
    }

}