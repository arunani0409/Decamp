package com.example.kcet;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PassStdPendFragment extends Fragment {

    ArrayList<LeaveStsList> list = new ArrayList<>();

    public String mUser,yr,dept,leaveId,path;
    public TextView no_data;
    View view;
    private ScrollView scrollView;
    private TextView name,roll,reason,start,year,time,r1;
    public ProgressDialog progressDialog;

    public PassStdPendFragment(String path, String mUser,String yr,String dept){
        this.mUser=mUser;this.path=path;this.yr=yr;this.dept=dept;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_pass_std_pend, container, false);
        scrollView=view.findViewById(R.id.layout);
        no_data=view.findViewById(R.id.no_data);
        name=view.findViewById(R.id.name);
        roll=view.findViewById(R.id.roll);
        start=view.findViewById(R.id.start);
        time=view.findViewById(R.id.time);
        year=view.findViewById(R.id.year);
        reason=view.findViewById(R.id.reason);
        r1=view.findViewById(R.id.r1);

        progressDialog= ProgressDialog.show(getContext(),null,null,true);
        progressDialog.setContentView(R.layout.prograss_bar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference("Pass/"+path+"/"+mUser);
        ValueEventListener eventListener = new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(DataSnapshot ds) {
                if (ds.exists()) {
                    for(DataSnapshot dataSnapshot:ds.getChildren())
                    {
                        if(dataSnapshot.child("status").getValue().toString().equals("Pending"))
                        {
                            scrollView.setVisibility(View.VISIBLE);
                            name.setText(dataSnapshot.child("name").getValue().toString());
                            roll.setText(mUser);
                            time.setText(dataSnapshot.child("time").getValue().toString());
                            start.setText(dataSnapshot.child("date").getValue().toString());
                            reason.setText(dataSnapshot.child("reason").getValue().toString());
                            year.setText(yr+" / "+dept);
                            leaveId=dataSnapshot.child("leaveId").getValue().toString();
                            no_data.setVisibility(View.INVISIBLE);
                        }
                        progressDialog.dismiss();
                    }
                }
                else {
                    progressDialog.dismiss();
                    no_data.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {Toast.makeText(getActivity(),"Something went wrong. Contact Admin!",Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();}
        };
        rootRef.addListenerForSingleValueEvent(eventListener);


        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),LeaveStatusActivity.class);
                intent.putExtra("yr",yr);
                intent.putExtra("roll",mUser);
                intent.putExtra("sts","Leave Approved");
                intent.putExtra("id",leaveId);
                intent.putExtra("dept",dept);
                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onDestroy() {
        if(progressDialog.isShowing())
            progressDialog.dismiss();
        super.onDestroy();
    }
}